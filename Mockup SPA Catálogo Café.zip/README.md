
  # Mockup SPA Catálogo Café

  This is a code bundle for Mockup SPA Catálogo Café. The original project is available at https://www.figma.com/design/TCCjvvxPtsCXQQXZ3vGWme/Mockup-SPA-Cat%C3%A1logo-Caf%C3%A9.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  