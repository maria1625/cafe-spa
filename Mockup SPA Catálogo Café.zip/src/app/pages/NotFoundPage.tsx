import { Link } from 'react-router';
import { Coffee } from 'lucide-react';
import { Button } from '../components/ui/button';

export function NotFoundPage() {
  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center px-4">
      <div className="text-center">
        <div className="mb-6">
          <Coffee className="size-24 text-[#6D4C41] mx-auto opacity-50" />
        </div>
        <h1 className="text-6xl font-bold text-[#3E2723] mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-[#3E2723] mb-2">
          Página no encontrada
        </h2>
        <p className="text-[#6D4C41] mb-8">
          Lo sentimos, la página que buscas no existe.
        </p>
        <Link to="/">
          <Button className="bg-[#6D4C41] hover:bg-[#5D4037] text-white">
            Volver al inicio
          </Button>
        </Link>
      </div>
    </div>
  );
}
