import { useAuth } from '../context/AuthContext';
import { Coffee, TrendingUp, ShoppingBag, Star } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

export function DashboardPage() {
  const { user } = useAuth();

  const stats = [
    {
      icon: ShoppingBag,
      label: 'Pedidos realizados',
      value: '12',
      color: 'bg-[#6D4C41]'
    },
    {
      icon: Star,
      label: 'Favoritos',
      value: '8',
      color: 'bg-[#8D6E63]'
    },
    {
      icon: TrendingUp,
      label: 'Puntos acumulados',
      value: '340',
      color: 'bg-[#5D4037]'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-[#3E2723] to-[#5D4037] rounded-xl p-8 mb-8 text-white shadow-xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-white/20 rounded-full p-3">
              <Coffee className="size-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">
                ¡Bienvenido, {user?.name}!
              </h1>
              <p className="text-white/80 mt-1">
                Tu espacio personal en CaféHub
              </p>
            </div>
          </div>
          <p className="text-white/90">
            Explora nuestro catálogo de cafés premium y encuentra tu mezcla perfecta
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="border-[#D7CCC8] hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-[#6D4C41]">
                    {stat.label}
                  </CardTitle>
                  <div className={`${stat.color} rounded-full p-2`}>
                    <Icon className="size-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-[#3E2723]">
                    {stat.value}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Recent Activity */}
        <Card className="border-[#D7CCC8]">
          <CardHeader>
            <CardTitle className="text-[#3E2723]">Actividad Reciente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { action: 'Pedido realizado', item: 'Ethiopian Yirgacheffe', date: '15 Mar 2026' },
                { action: 'Agregado a favoritos', item: 'Italian Espresso', date: '10 Mar 2026' },
                { action: 'Valoración enviada', item: 'Colombian Supremo', date: '05 Mar 2026' }
              ].map((activity, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between py-3 border-b border-[#EFEBE9] last:border-0"
                >
                  <div>
                    <p className="font-medium text-[#3E2723]">{activity.action}</p>
                    <p className="text-sm text-[#6D4C41]">{activity.item}</p>
                  </div>
                  <span className="text-sm text-[#8D6E63]">{activity.date}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
