import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { Coffee, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';

export function RegisterPage() {
  const navigate = useNavigate();
  const { register, isLoading } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name || !email || !password || !confirmPassword) {
      setError('Por favor completa todos los campos');
      return;
    }

    if (password !== confirmPassword) {
      setError('Las contraseñas no coinciden');
      return;
    }

    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    const result = await register(name, email, password);
    
    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error || 'Error al registrar usuario');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#EFEBE9] to-[#D7CCC8] flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-[#D7CCC8] shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto bg-[#3E2723] rounded-full p-4 w-fit">
            <Coffee className="size-10 text-white" />
          </div>
          <CardTitle className="text-2xl text-[#3E2723]">
            Crear Cuenta
          </CardTitle>
          <CardDescription className="text-[#6D4C41]">
            Únete a la comunidad de CaféHub
          </CardDescription>
        </CardHeader>

        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="name" className="text-[#3E2723]">
                Nombre completo
              </Label>
              <Input
                id="name"
                type="text"
                placeholder="Juan Pérez"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="border-[#D7CCC8] focus:ring-[#6D4C41] focus:border-[#6D4C41]"
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#3E2723]">
                Correo electrónico
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-[#D7CCC8] focus:ring-[#6D4C41] focus:border-[#6D4C41]"
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-[#3E2723]">
                Contraseña
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border-[#D7CCC8] focus:ring-[#6D4C41] focus:border-[#6D4C41]"
                disabled={isLoading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-[#3E2723]">
                Confirmar contraseña
              </Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="border-[#D7CCC8] focus:ring-[#6D4C41] focus:border-[#6D4C41]"
                disabled={isLoading}
              />
            </div>
          </CardContent>

          <CardFooter className="flex flex-col gap-4">
            <Button
              type="submit"
              className="w-full bg-[#6D4C41] hover:bg-[#5D4037] text-white"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Registrando...
                </>
              ) : (
                'Crear cuenta'
              )}
            </Button>

            <p className="text-sm text-[#6D4C41] text-center">
              ¿Ya tienes cuenta?{' '}
              <Link to="/login" className="text-[#3E2723] font-semibold hover:underline">
                Inicia sesión
              </Link>
            </p>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
