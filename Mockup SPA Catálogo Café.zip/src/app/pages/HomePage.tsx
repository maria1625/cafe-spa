import { useState, useMemo } from 'react';
import { CoffeeCard } from '../components/CoffeeCard';
import { FilterBar } from '../components/FilterBar';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { coffees } from '../data/coffees';

export function HomePage() {
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);
  const [sortBy, setSortBy] = useState('name');

  const filteredAndSortedCoffees = useMemo(() => {
    let result = [...coffees];

    // Filter
    if (showAvailableOnly) {
      result = result.filter(coffee => coffee.available);
    }

    // Sort
    switch (sortBy) {
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
    }

    return result;
  }, [showAvailableOnly, sortBy]);

  const handleRetry = () => {
    setHasError(false);
    setIsLoading(true);
    // Simular recarga
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-[#3E2723] mb-2">
            Catálogo de Café Premium
          </h1>
          <p className="text-[#6D4C41]">
            Descubre nuestra selección de cafés de origen único
          </p>
        </div>

        {/* Filter Bar */}
        <FilterBar
          showAvailableOnly={showAvailableOnly}
          onShowAvailableChange={setShowAvailableOnly}
          sortBy={sortBy}
          onSortChange={setSortBy}
        />

        {/* Content */}
        {isLoading ? (
          <LoadingState />
        ) : hasError ? (
          <ErrorState onRetry={handleRetry} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedCoffees.map((coffee) => (
              <CoffeeCard key={coffee.id} coffee={coffee} />
            ))}
          </div>
        )}

        {!isLoading && !hasError && filteredAndSortedCoffees.length === 0 && (
          <div className="text-center py-16">
            <p className="text-[#6D4C41] text-lg">
              No se encontraron cafés con los filtros seleccionados
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
