export interface Coffee {
  id: number;
  name: string;
  brand: string;
  price: number;
  rating: number;
  votes: number;
  image: string;
  available: boolean;
  description: string;
  origin: string;
  roast: string;
}

export const coffees: Coffee[] = [
  {
    id: 1,
    name: "Ethiopian Yirgacheffe",
    brand: "Premium Roasters",
    price: 18.99,
    rating: 4.8,
    votes: 245,
    image: "https://images.unsplash.com/photo-1646325742177-21f298f470c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBiZWFucyUyMGRhcmslMjByb2FzdHxlbnwxfHx8fDE3NzM4OTE2OTh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    description: "Notas florales y cítricas con cuerpo ligero",
    origin: "Etiopía",
    roast: "Medio"
  },
  {
    id: 2,
    name: "Colombian Supremo",
    brand: "Café del Valle",
    price: 16.50,
    rating: 4.6,
    votes: 189,
    image: "https://images.unsplash.com/photo-1645445644664-8f44112f334c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3ByZXNzbyUyMGNvZmZlZSUyMGN1cHxlbnwxfHx8fDE3NzM4NzIyMDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    description: "Equilibrado con notas de caramelo y nuez",
    origin: "Colombia",
    roast: "Medio"
  },
  {
    id: 3,
    name: "Brazilian Santos",
    brand: "Tropical Beans",
    price: 14.99,
    rating: 4.4,
    votes: 156,
    image: "https://images.unsplash.com/photo-1690145406811-4435335fa643?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcmFiaWNhJTIwY29mZmVlJTIwYmFnfGVufDF8fHx8MTc3Mzk2MjkwOHww&ixlib=rb-4.1.0&q=80&w=1080",
    available: false,
    description: "Sabor suave con bajo nivel de acidez",
    origin: "Brasil",
    roast: "Claro"
  },
  {
    id: 4,
    name: "Italian Espresso",
    brand: "Caffè Italiano",
    price: 22.00,
    rating: 4.9,
    votes: 312,
    image: "https://images.unsplash.com/photo-1667388363683-a07bbf0c84b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXBwdWNjaW5vJTIwbGF0dGUlMjBhcnR8ZW58MXx8fHwxNzczODc3MjM5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    description: "Intenso y cremoso, perfecto para espresso",
    origin: "Italia",
    roast: "Oscuro"
  },
  {
    id: 5,
    name: "Kenyan AA",
    brand: "African Heritage",
    price: 19.99,
    rating: 4.7,
    votes: 203,
    image: "https://images.unsplash.com/photo-1626376010399-a82e5ce6de37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjByb2FzdGluZyUyMGJlYW5zfGVufDF8fHx8MTc3Mzk0NTAyOXww&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    description: "Acidez vibrante con notas de frutos rojos",
    origin: "Kenia",
    roast: "Medio-Oscuro"
  },
  {
    id: 6,
    name: "Sumatra Mandheling",
    brand: "Island Brews",
    price: 17.50,
    rating: 4.5,
    votes: 178,
    image: "https://images.unsplash.com/photo-1695502992934-3c7dd5546107?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVuY2glMjBwcmVzcyUyMGNvZmZlZXxlbnwxfHx8fDE3NzM5NDYyOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    description: "Terroso con cuerpo completo y baja acidez",
    origin: "Indonesia",
    roast: "Oscuro"
  }
];
