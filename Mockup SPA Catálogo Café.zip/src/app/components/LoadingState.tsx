import { Coffee } from 'lucide-react';

interface LoadingStateProps {
  message?: string;
}

export function LoadingState({ message = 'Cargando cafés...' }: LoadingStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16">
      <div className="relative">
        <Coffee className="size-16 text-[#6D4C41] animate-pulse" />
        <div className="absolute inset-0 bg-[#6D4C41]/20 rounded-full blur-xl animate-pulse" />
      </div>
      <p className="mt-4 text-[#3E2723] font-medium">{message}</p>
    </div>
  );
}
