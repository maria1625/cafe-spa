import { AlertCircle } from 'lucide-react';
import { Button } from './ui/button';

interface ErrorStateProps {
  message?: string;
  onRetry?: () => void;
}

export function ErrorState({ 
  message = 'Error al cargar los cafés', 
  onRetry 
}: ErrorStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16">
      <div className="bg-red-50 rounded-full p-6 mb-4">
        <AlertCircle className="size-12 text-red-600" />
      </div>
      <h3 className="text-xl font-semibold text-[#3E2723] mb-2">
        {message}
      </h3>
      <p className="text-[#6D4C41] mb-6">
        Por favor, intenta de nuevo
      </p>
      {onRetry && (
        <Button
          onClick={onRetry}
          className="bg-[#6D4C41] hover:bg-[#5D4037] text-white"
        >
          Reintentar
        </Button>
      )}
    </div>
  );
}
