import { Star } from 'lucide-react';
import { Coffee } from '../data/coffees';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';

interface CoffeeCardProps {
  coffee: Coffee;
}

export function CoffeeCard({ coffee }: CoffeeCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300 border-[#D7CCC8]">
      <div className="relative h-48 overflow-hidden bg-[#EFEBE9]">
        <img
          src={coffee.image}
          alt={coffee.name}
          className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
        />
        {!coffee.available && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <Badge variant="destructive" className="text-sm">
              No disponible
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex-1">
            <h3 className="font-semibold text-[#3E2723] line-clamp-1">
              {coffee.name}
            </h3>
            <p className="text-sm text-[#6D4C41]">{coffee.brand}</p>
          </div>
          <div className="text-right">
            <p className="font-bold text-[#3E2723]">${coffee.price}</p>
          </div>
        </div>

        <p className="text-sm text-[#8D6E63] mb-3 line-clamp-2">
          {coffee.description}
        </p>

        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <span className="text-xs text-[#6D4C41]">Origen:</span>
            <span className="text-xs font-medium text-[#3E2723]">{coffee.origin}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-xs text-[#6D4C41]">Tueste:</span>
            <span className="text-xs font-medium text-[#3E2723]">{coffee.roast}</span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="px-4 pb-4 pt-0 flex items-center justify-between border-t border-[#EFEBE9]">
        <div className="flex items-center gap-1">
          <Star className="size-4 fill-[#FFA726] text-[#FFA726]" />
          <span className="font-semibold text-[#3E2723]">{coffee.rating}</span>
          <span className="text-sm text-[#8D6E63]">({coffee.votes})</span>
        </div>
      </CardFooter>
    </Card>
  );
}
