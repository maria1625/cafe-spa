import { Link, useNavigate } from 'react-router';
import { Coffee, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui/button';

export function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-[#3E2723] text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <Coffee className="size-8" />
            <span className="font-semibold text-xl">CaféHub</span>
          </Link>

          {/* Navigation Links */}
          <div className="flex items-center gap-6">
            <Link 
              to="/" 
              className="hover:text-[#D7CCC8] transition-colors"
            >
              Inicio
            </Link>

            {user ? (
              <>
                <Link 
                  to="/dashboard" 
                  className="hover:text-[#D7CCC8] transition-colors"
                >
                  Dashboard
                </Link>
                <div className="flex items-center gap-3 ml-4 pl-4 border-l border-[#6D4C41]">
                  <span className="text-[#D7CCC8]">Hola, {user.name}</span>
                  <Button
                    onClick={handleLogout}
                    variant="ghost"
                    size="sm"
                    className="text-white hover:bg-[#4E342E] hover:text-white"
                  >
                    <LogOut className="size-4 mr-2" />
                    Salir
                  </Button>
                </div>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="hover:text-[#D7CCC8] transition-colors"
                >
                  Login
                </Link>
                <Link 
                  to="/register"
                  className="bg-[#6D4C41] hover:bg-[#5D4037] px-4 py-2 rounded-lg transition-colors"
                >
                  Registro
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
