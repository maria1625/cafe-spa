import { Checkbox } from './ui/checkbox';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface FilterBarProps {
  showAvailableOnly: boolean;
  onShowAvailableChange: (checked: boolean) => void;
  sortBy: string;
  onSortChange: (value: string) => void;
}

export function FilterBar({
  showAvailableOnly,
  onShowAvailableChange,
  sortBy,
  onSortChange,
}: FilterBarProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6 border border-[#D7CCC8]">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        {/* Checkbox */}
        <div className="flex items-center space-x-2">
          <Checkbox
            id="available"
            checked={showAvailableOnly}
            onCheckedChange={onShowAvailableChange}
            className="border-[#6D4C41] data-[state=checked]:bg-[#6D4C41] data-[state=checked]:border-[#6D4C41]"
          />
          <Label
            htmlFor="available"
            className="text-[#3E2723] cursor-pointer"
          >
            Solo disponibles
          </Label>
        </div>

        {/* Sort Select */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Label className="text-[#3E2723] whitespace-nowrap">
            Ordenar por:
          </Label>
          <Select value={sortBy} onValueChange={onSortChange}>
            <SelectTrigger className="w-full sm:w-[200px] border-[#D7CCC8] focus:ring-[#6D4C41]">
              <SelectValue placeholder="Seleccionar..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Nombre</SelectItem>
              <SelectItem value="price-asc">Precio: Menor a Mayor</SelectItem>
              <SelectItem value="price-desc">Precio: Mayor a Menor</SelectItem>
              <SelectItem value="rating">Mejor Valorados</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
